package com.example.WorkIt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkItApplicationTests {

	@Test
	void contextLoads() {
	}

}

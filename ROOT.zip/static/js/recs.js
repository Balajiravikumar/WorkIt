String.prototype.startsWith=function(prefix){return this.indexOf(prefix) === 0;};
String.prototype.endsWith=function(suffix){return this.match(suffix+"$") == suffix;};
function postParams(url,params){
	var input = "<input type='hidden' id='view-state' name='view-state' value=''>"+$('#logout').html();
	if(params){for (var name in params) { if(Array.isArray(params[name])){
		for (var ix = 0; ix < params[name].length; ix++){
			input = input + "<input type='hidden' id='"+name+"' name='"+name+"' value='"+params[name][ix]+"'>";
		}
	}else{input = input + "<input type='hidden' id='"+name+"' name='"+name+"' value='"+params[name]+"'>"; }}}
	$('<form/>',{action:url,method: 'post',css:{display:'none'},html:input}).appendTo('body').submit();
}
function escapeHtmlTag(txt){return txt.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");}
$.fn.onlyNumeric=function(allowNegative){
    return this.each(function(){
    	if(allowNegative!=undefined && allowNegative==true){
        	$(this).data('allowNegative',true);
        }
    	var arrAllowed=[46, 8, 9, 27, 13, 110];
    	if($(this).data('allowNegative')){
    		$(this).data('val',$(this).val());
    		arrAllowed.push(189);
    		if($(this).val().indexOf('-')!=-1 && e.which==189){e.preventDefault();}
    	}
        $(this).css('text-align','right').keydown(function(e){
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 || (e.keyCode == 65 && e.ctrlKey === true) || (e.keyCode >= 35 && e.keyCode <= 39)) {return;}
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {e.preventDefault();}
        });
        if($(this).data('allowNegative')){
			$(this).unbind("keyup.onlyNumeric").bind( "keyup.onlyNumeric", function(){
    		//$(this).keyup(function(){
    			if($(this).val().indexOf('-')!=-1 && $(this).val().indexOf('-')!=0){$(this).val($(this).data('val'));}
    		});
    	}
    });
};
$.fn.onlyDecimal=function(allowNegative){
    return this.each(function(){
    	if(allowNegative!=undefined && allowNegative==true){
        	$(this).data('allowNegative',true);
        }
        $(this).css('text-align','right').keydown(function(e){
	
			//alert("e.shiftKey:"+e.shiftKey+"  e.ctrlKey:"+e.ctrlKey+"  e.which:"+e.which+"  e.keyCode:"+e.keyCode);
			
        	if($(this).val().indexOf('.')!=-1 && e.which==190 ){e.preventDefault();}
			if(e.which==190 && e.shiftKey===true){e.preventDefault();}

        	var arrAllowed=[46, 8, 9, 27, 13, 110, 190];
        	if($(this).data('allowNegative')){
        		$(this).data('val',$(this).val());
        		arrAllowed.push(189);
        		if($(this).val().indexOf('-')!=-1 && e.which==189){e.preventDefault();}
        	}
            if ($.inArray(e.keyCode, arrAllowed) !== -1 || (e.keyCode == 65 && e.ctrlKey === true) || (e.keyCode >= 35 && e.keyCode <= 39)) {return;}
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {e.preventDefault();}
        });
        if($(this).data('allowNegative')){
			$(this).unbind("keyup.onlyDecimal").bind( "keyup.onlyDecimal", function(){
    		//$(this).keyup(function(){
    			if($(this).val().indexOf('-')!=-1 && $(this).val().indexOf('-')!=0){$(this).val($(this).data('val'));}
    		});
    	}
    });
};

$.fn.filterDecimal=function(allowNegative){
    return this.each(function(){
    	if(allowNegative!=undefined && allowNegative==true){
        	$(this).data('allowNegative',true);
        }
        $(this).css('text-align','right').keydown(function(e){
			
			//alert("e.shiftKey:"+e.shiftKey+"  e.ctrlKey:"+e.ctrlKey+"  e.which:"+e.which+"  e.keyCode:"+e.keyCode);
			
        	if($(this).val().indexOf('.')!=-1 && e.which==190 ){e.preventDefault();}
			//if(e.which==190 && e.shiftKey===true){e.preventDefault();}
			
			if(e.which==188 && e.shiftKey===false){e.preventDefault();}
			if(e.which==187 && e.shiftKey===true){e.preventDefault();}
			
			let vv=$(this).val();
			if(vv!=''){
				if(e.which==188 && e.shiftKey===true){e.preventDefault();}
				if(vv!='<' && e.which==190 && e.shiftKey===true){e.preventDefault();}
			}
			
			if(e.which==187 && e.shiftKey===false){
				if(vv=='<'){
					$(this).val('<=');
				}
				if(vv=='>'){
					$(this).val('>=');
				}
				e.preventDefault();
			}

        	var arrAllowed=[46, 8, 9, 27, 13, 110, 187,188,190];
        	if($(this).data('allowNegative')){
        		$(this).data('val',$(this).val());
        		arrAllowed.push(189);
        		if($(this).val().indexOf('-')!=-1 && e.which==189){e.preventDefault();}
        	}
            if ($.inArray(e.keyCode, arrAllowed) !== -1 || (e.keyCode == 65 && e.ctrlKey === true) || (e.keyCode >= 35 && e.keyCode <= 39)) {return;}
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {e.preventDefault();}
        });
        if($(this).data('allowNegative')){
			$(this).unbind("keyup.onlyDecimal").bind( "keyup.onlyDecimal", function(){
    			if($(this).val().indexOf('-')!=-1 && $(this).val().indexOf('-')!=0){$(this).val($(this).data('val'));}
    		});
    	}
    });
};

$.fn.minVal=function(minValue){
    return this.each(function(){
		if($(this).val()!='' && $(this).val() < minValue){$(this).val(minValue);}
		if($(this).val()==''){$(this).val(minValue);}
		$(this).onlyNumeric().unbind("keyup.minVal").bind( "keyup.minVal", function(){
        //$(this).onlyNumeric().keyup(function(e){
        	if($(this).val()!='' && $(this).val() < minValue){$(this).val(minValue);}
			if($(this).val()==''){$(this).val(minValue);}
        });
    });
};	
$.fn.maxVal=function(maxValue){
    return this.each(function(){
		if($(this).val()!='' && $(this).val() > maxValue){$(this).val(maxValue);}
		$(this).onlyNumeric().unbind("keyup.maxVal").bind( "keyup.maxVal", function(){
        //$(this).onlyNumeric().keyup(function(e){
           if($(this).val()!='' && $(this).val() > maxValue){$(this).val(maxValue);}
        });
    });
};
$.fn.defaultVal=function(defVal){
    return this.each(function(){
		if($(this).val()==''){$(this).val(defVal);}
        //$(this).keyup(function(e){if($(this).val()==''){$(this).val(defVal);}});
		$(this).unbind("keyup.defaultVal").bind( "keyup.defaultVal", function(){if($(this).val()==''){$(this).val(defVal);}});
    });
};	
$.fn.enter=function(fnctn){
    return this.each(function(){
		$(this).unbind("keypress.enter").bind( "keypress.enter", function(e){
        //$(this).keypress(function(e){
        	if ((e.keyCode ? e.keyCode : e.which) == '13') {
        		fnctn.call(this,e);
        	}
        });
    });
};
$.fn.setCursorPosition = function(pos) {
  this.each(function(index, elem) {
    if (elem.setSelectionRange) {
      elem.setSelectionRange(pos, pos);
    } else if (elem.createTextRange) {
      var range = elem.createTextRange();
      range.collapse(true);
      range.moveEnd('character', pos);
      range.moveStart('character', pos);
      range.select();
    }
  });
  return this;
};
function elZIndx(elm) {
  //var elm = $('#'+eleman);
  var zindex = parseInt(elm.css("z-index")) > 0 ? elm.css("z-index") : 0;
  while(true) {
    zindex = (parseInt(elm.css("z-index")) > 0 && parseInt(elm.css("z-index")) > zindex) ? elm.css("z-index") : zindex;
    if(elm.length > 0) {
      elm = elm.parent();
    } else {
      break;
    }
  }
  return zindex;
}

$.fn.zIndex = function(){
	var zIndx = 0;
	var elm = $(this);
	while(!elm.is($('body')) && isNaN(elm.css('zIndex')) ){
		elm=elm.parent();
	}
	if(!isNaN(elm.css('zIndex'))){
		zIndx=parseInt(elm.css('zIndex'));
	}
	return zIndx;
}

$.fn.maxZEl =  function(){var elements = $(this).filter(":visible");var maxZEl = elements.eq(0);elements.each(function(){if($(this).zIndex() >= maxZEl.zIndex())maxZEl = $(this);});return maxZEl;};

var aftrCntxtPth = "";
/*alert($(location).attr('pathname'));
if(conf.contextPath==""){
	aftrCntxtPth = $(location).attr('pathname');
}else{
	aftrCntxtPth = $(location).attr('href').split(conf.contextPath)[1];	
}*/
aftrCntxtPth = $(location).attr('pathname');
function noBack(){window.history.forward();}
var recsAlert=function(title,message){$('<div></div>').text(message).dialog({maxHeight:400,maxWidth:500,autoOpen:true,modal:true,title:title,buttons: {'Ok':function(){$(this).dialog('destroy').remove();}}});};
var recsTextAlert=function(title,message){
	let dlg = $('<div style="overflow:hidden !important;" class="text-alert"><textarea readonly="readonly" wrap="off" style="width:100%;height:100%;resize: none;"></textarea></div>');
	dlg.find('textarea').val(message).setCursorPosition(0);
	dlg.dialog({maxHeight:500,maxWidth:600,width:400,height:300,autoOpen:true,modal:true,title:title,buttons: {'Ok':function(){$(this).dialog('destroy').remove();}}});
};


window.alert = function(message){$('<div></div>').text(message).dialog({maxHeight:400,maxWidth:500,autoOpen:true,modal:true,title:'Alert',buttons: {'Ok':function(){$(this).dialog('destroy').remove();}}});};
window.confirm = function(message,callBack,okLbl,cancelLbl){
	var dlg = $('<div/>').text(message).dialog({
		maxHeight:400,maxWidth:500,autoOpen:true,modal:true,resizable:false,title:'Confirm',
		buttons:[{text:((okLbl!=undefined)?okLbl:"Ok"),click:function(){dlg.dialog('destroy').remove();callBack.apply(this,[true]);}},
		  {text:((cancelLbl!=undefined)?cancelLbl:"Cancel"),click:function(){dlg.dialog('destroy').remove();callBack.apply(this,[false]);}}]
	});
};
$.fn.expressionbuilder=function(expressionbuilderdata){//datatype can be number,string,boolean or datetime
	return this.each(function(){//expressionbuilderdata = {datatype:'string',operators:['-','+','*','/'],functions:['concatstr','strlen','addint','currtime'],columns:['ID','F_NAME','L_NAME','DEPT','LOCATION']}
		var el = $(this).data('expressionbuilderdata',expressionbuilderdata).data('cols',[]);
		//$('<table style="float:left;"><tr><td class="ui-state-disabled expressionelement operator" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Operator</td><td class="ui-state-disabled expressionelement function" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Function</td><td class="ui-state-disabled expressionelement column" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Column</td><td class="ui-state-disabled expressionelement literal" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Literal</td></tr></table>')
		$('<table style="float:left;"><tr><td class="expressionelement operator" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Operator</td><td class="expressionelement function" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Function</td><td class="expressionelement column" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Column or Variable</td></tr></table>')
		//$('<table style="float:left;"><tr><td class="ui-state-disabled expressionelement function" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Function</td><td class="ui-state-disabled expressionelement column" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Column</td><td class="ui-state-disabled expressionelement literal" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Literal</td></tr></table>')
		.appendTo($(this)/*.disableSelection()*/.css({height:'25px',fontSize:'14px'})).attr('datatype',expressionbuilderdata.datatype);
		var popid = $(this).attr('id')+'_'+Math.floor((Math.random()*10000)+1)+'_'+(new Date().getMilliseconds());
		$('<div style="width:200px; height:100px; z-index: 10; position: absolute;display:none;" class="expressionpop"><table class="ui-widget-content" style="border-collapse: collapse; width:100%; height:100%; position: absolute; top:0px; left:0px;"><tr style="height: 20px;" class="ui-widget-header"><th id="expressionhandle" style="border: 1px solid #c3d9ff;cursor: move;font-size:1rem;"></th></tr><tr><td align="center" id="expressioncontent"></td></tr><tr><td align="center"><button id="ok">Ok</button>&nbsp;&nbsp;&nbsp;&nbsp;<button id="cancel">Cancel</button></td></tr></table></div>')
		.appendTo($(this)).attr('id',popid).find('button').button().click(function(){
			
			if($(this).attr('id')=='ok'){
				var expval = '';
				var color='#'+(Math.random().toString(16) + '0000000').slice(2, 8);
				if($(this).closest('tr').prev().find('select').length!=0){expval = $(this).closest('tr').prev().find('select').val();}
				else{expval = $(this).closest('tr').prev().find('input').val();}
				if(expval!='' && expval!='select'){
					if($('#'+popid).data('expressionelement').is('.operator')){
						var tbl = $('#'+popid).data('expressionelement').closest('table');
						var expdata = tbl.parent().data('expressionbuilderdata');
						var argdatatypes = expdata.operatorargumentdatatypes[$.inArray(expval,expdata.operators)];
						var tempTbl;
						if(argdatatypes.length==2){
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
							tempTbl = tbl.clone().attr('datatype',argdatatypes[1]);
							tempTbl.find('.expressionelement').each(function(){
								var dtTyp = tempTbl.attr('datatype');
								var thisVis=false;
								if($(this).is('.operator')){
									for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.function')){
									for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.column')){
									for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}
							});
							tbl.after(tempTbl);
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">&nbsp; '+expval+' &nbsp;</div>');
							tempTbl = tbl.clone().attr('datatype',argdatatypes[0]);
							tempTbl.find('.expressionelement').each(function(){
								var dtTyp = tempTbl.attr('datatype');
								var thisVis=false;
								if($(this).is('.operator')){
									for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.function')){
									for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.column')){
									for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}
							});
							tbl.after(tempTbl);
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">(</div>');
						}else if(argdatatypes.length==1){
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
							tbl.after(tbl.clone().attr('datatype',argdatatypes[0]));
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'</div>');
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">(</div>');
						}
					}else if($('#'+popid).data('expressionelement').is('.function')){
						var tbl = $('#'+popid).data('expressionelement').closest('table');
						var expdata = tbl.parent().data('expressionbuilderdata');
						var argdatatypes = expdata.functionargumentdatatypes[$.inArray(expval,expdata.functions)];
						var tempTbl;
						if(argdatatypes.length > 0){
							for ( var i = (argdatatypes.length - 1); i >= 0 ; i--) {
								tempTbl = tbl.clone().attr('datatype',argdatatypes[i]);
								//alert(argdatatypes[i]);
								tempTbl.find('.expressionelement').each(function(){
									var dtTyp = tempTbl.attr('datatype');
									var thisVis=false;
									if($(this).is('.operator')){
										for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
									}else if($(this).is('.function')){
										for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
									}else if($(this).is('.column')){
										for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if('any'==dtTyp || dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
									}
								});
								if(i==(argdatatypes.length - 1)){
									if(argdatatypes.length==1){
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
										tbl.after(tempTbl);
										tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'(</div>');
									}else{
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
										tbl.after(tempTbl);
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">,</div>');
									}
								}else if(i==0){
									tbl.after(tempTbl);
									tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'(</div>');
								}else{
									tbl.after(tempTbl);
									tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">,</div>');
								}
							}	
						}else{
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'()</div>');
						}
					}else if($('#'+popid).data('expressionelement').is('.column')){
						$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">'+expval+'</div>');
						var cols = el.data('cols');
						if($.inArray(expval,cols)==-1){
							cols.push(expval);
						}
						el.data('cols',cols);
					}else if($('#'+popid).data('expressionelement').is('.literal')){
						if($('#'+popid).data('expressionelement').closest('table').attr('datatype') == 'string'){
							$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">\''+expval+'\'</div>');
						}else if($('#'+popid).data('expressionelement').closest('table').attr('datatype') == 'datetime'){
							$('#'+popid).data('expressionelement').closest('table').replaceWith("<div style=\"float:left;color:"+color+";\">todate('"+expval+"','MM/dd/yyyy hh:mm aa')</div>");
						}else{
							$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">'+expval+'</div>');
						}
					}
					$('#'+popid).hide();
				}
			}else if($(this).attr('id')=='cancel'){$('#'+popid).hide();}
		});
		var _hideexpressionspopup = function(ev){
			if (!($('#'+popid).is(ev.target)) && $('#'+popid).has(ev.target).length === 0 && $(ev.target).closest('.ui-datepicker').length == 0
		&& $(ev.target).closest('.ui-datepicker-header').length == 0 && $(ev.target).closest('.ui-selectmenu-menu').length == 0
		){$('#'+popid).hide();}};
		$(this).find('.expressionelement').each(function(){
			var dtTyp = $(this).closest('table').attr('datatype');
			var thisVis=false;
			if($(this).is('.operator')){
				for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.function')){
				for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.column')){
				for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}
		});
		$(this).on('click','.expressionelement',function(e){
			$('#'+popid).show().draggable({handle:$('#expressionhandle'),containment:'document'}).data('expressionelement',$(this)).position({of:$(this),at:"left bottom",my:"left top"}).find('#expressionhandle').html($(this).html());
			$(document).unbind('click',_hideexpressionspopup).click(_hideexpressionspopup);
			e.preventDefault();e.stopPropagation();$(document).find('.expressionpop:not("#'+popid+'")').hide();
			var expcont = $('#'+popid).find('#expressioncontent').html('');
			var inputStr = '';
			var dt = $(this).closest('table').attr('datatype');
			if($(this).is('.operator')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dt==expressionbuilderdata.operatordatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.operators[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr)/*.find('select').selectmenu()*/;
			}else if($(this).is('.function')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.functions.length; i++){if(dt==expressionbuilderdata.functiondatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.functions[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr)/*.find('select').selectmenu()*/;
			}else if($(this).is('.column')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.columns.length; i++){if('any'==dt || dt==expressionbuilderdata.columndatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.columns[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr)/*.find('select').selectmenu()*/;
			}else if($(this).is('.literal')){
				inputStr = '<input style="width:70%;">';
				expcont.append(inputStr);
				if(dt=='number'){
					expcont.find('input').keydown(function(e){
						if(e.keyCode==190 && $(this).val().indexOf(".")!=-1){e.preventDefault();}
						if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || (e.keyCode >= 35 && e.keyCode <= 40)) {return;}
					    if((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || (e.keyCode > 105))){e.preventDefault();}
					});
				}else if(dt=='datetime'){
					expcont.find('input').datetimepicker({timeFormat:"hh:mm tt"});
				}
			}
		});
	});
};
$.fn.contextMenu = function (data, options) {
    var $body = $("body"),
        defaults = {
            name: "",  
            offsetX: 15, 
            offsetY: 5,
            beforeShow: $.noop, 
            afterShow: $.noop 
        };
    var params = $.extend(defaults, options || {}), keyMap = {},
        idKey = "recs_cm_", classKey = "recs-cm-",
        name = name || ("RCM_" + +new Date() + (Math.floor(Math.random() * 1000) + 1)),
        count = 0;      
    var buildMenuHtml = function (mdata) {
            var menuData = mdata || data,
                idName = idKey + (mdata ? count++ : name),
                className = classKey + "box";
            var $mbox = $('<div id="' + idName + '" class="' + className + '" style="position:absolute; display: none;">');
            $.each(menuData, function (index, group) {
                if (!$.isArray(group)) {
                    throw TypeError();
                }
                index && $mbox.append('<div class="' + classKey + 'separ">');
                if (!group.length) {
                    return;
                }
                var $ul = $('<ul class="' + classKey + 'group" style="padding-inline-start: 5px;list-style-type:none;border:1px solid #c3d9ff;">');
                $.each(group, function (innerIndex, item) {
                    var key, $li = $("<li style='cursor:pointer;'>" + item.text + ($.isArray(item.items) && item.items.length ? buildMenuHtml(item.items) : "") + "</li>");
                    $.isFunction(item.action) && (key = (name + "_" + count + "_" + index + "_" + innerIndex), keyMap[key] = item.action, $li.attr("data-key", key));
                    $ul.append($li).appendTo($mbox);
                });
            });
            var html = $mbox.get(0).outerHTML;
            $mbox = null;
            return html;
        },           
        createContextMenu = function (rightClickEl) {
            var $menu = $("#" + idKey + name);
            if (!$menu.length) {
                var html = buildMenuHtml();
                $menu = $(html).appendTo($body);
                $("li", $menu).on("mouseover", function () {
                    $(this).addClass("hover").children("." + classKey + "box").show();
                }).on("mouseout", function () {
                    $(this).removeClass("hover").children("." + classKey + "box").hide();
                }).on("click", function (e) {
                    var key = $(this).data("key");
                   // alert(rightClickEl.attr('id'));
                    key && (keyMap[key].call(this,rightClickEl,$(e.target).parent()) !== false) && $menu.hide(); 
                });
                $menu.on("contextmenu", function () {
                    return false;
                });
            }
            return $menu;
        };
    $body.on("mousedown", function (e) {
        var jid = ("#" + idKey + name);
        !$(e.target).closest(jid).length && $(jid).hide();
    });
    return this.each(function () {
        $(this).on("contextmenu", function (e) {
            if ($.isFunction(params.beforeShow) && params.beforeShow.call(this, e) === false) {
                return;
            }
            e.cancelBubble = true;
            e.preventDefault();
            var $menu = createContextMenu($(e.target).parent());
            //alert($(e.target).parent());
            $menu.show().offset({left: e.clientX + params.offsetX, top: e.clientY + params.offsetY});

            $.isFunction(params.afterShow) && params.afterShow.call(this, e)
        });

    });
};
$(function() {
	$(document).ajaxSend(function(e, xhr, options) {ajaxPreHook(options.url);xhr.setRequestHeader($("meta[name='_csrf_header']").attr("content"), $("meta[name='_csrf']").attr("content"));});
	$(document).ajaxComplete(function(e, xhr, options){ajaxPostHook(options.url);});
	var dialogContainment ={ _makeDraggable_back: $.ui.dialog.prototype._makeDraggable,_makeDraggable: function () {this._makeDraggable_back(); this.uiDialog.draggable("option", "containment", ".menunbody");}};
	$.extend($.ui.dialog.prototype, dialogContainment);
	
	$.datepicker.setDefaults({showOn: "button",buttonImage: conf.contextPath+"/static/css/images/Calendar.png", buttonImageOnly: true ,dateFormat:'dd-M-yy',changeMonth:true,changeYear:true});
	$.timepicker.setDefaults({timeFormat:'hh:mm TT',buttonText:'Select Date/Time'});
	
	$('button').button();
	$('.nestedmenu').find('li>a').each(function(){
		$(this).removeClass('selectedmenu');
		//var path = $(this).attr('href').split(conf.contextPath)[1];
		//if(aftrCntxtPth.startsWith(path)){
		//if(aftrCntxtPth.startsWith($(this).attr('href').split('/')[1])){
		if(aftrCntxtPth.startsWith($(this).attr('href'))){
		//if(aftrCntxtPth.includes($(this).attr('href'))){
			$(this).addClass('selectedmenu').parents('li').find('>a').addClass('selectedmenu');
			//alert(aftrCntxtPth +"     :     "+$(this).attr('href'));
		}
	});
	
	$(document).on("contextmenu",function(){return false;}).tooltip(); 
	
	/*//select first option to make gray
	$('select:not(:disabled) option[value=0]').css('color','#D3D3D3');
	$('select:not(:disabled) option').not('[value=0]').css('color','black');
    $('select:not(:disabled)').each(function(){if($(this).val()=='0'){$(this).css('color','#D3D3D3');}}).change(function() {
       if ($(this).val() != '0') {$(this).css('color','black');} else { $(this).css('color','#D3D3D3');}
    });
	*/
	
	$(window).resize(function() {$('.footer').position({of: $('.menunbody'), my: "left top", at: "left bottom "});});
	$(window).scroll(function() {$('.footer').position({of: $('.menunbody'), my: "left bottom", at: "left bottom "});});
	
	$(".recsTree").disableSelection().find('li').each(function(){
		if($(this).find('>ul').length > 0){
			$(this).prepend("<span class='ui-icon ui-icon-folder-open' style='float:left;cursor:pointer;'></span>")
			.click(function(event){
				//alert($(event.target).html());
				//alert($(event.target).has('> .ui-icon-bullet').length < 1);
				if($(event.target).has('> .ui-icon-bullet').length < 1){
					$(this).find(".ui-icon-folder-collapsed,.ui-icon-folder-open").toggleClass("ui-icon-folder-collapsed ui-icon-folder-open").siblings("ul").toggle();
				}
				event.preventDefault();event.stopPropagation();
			});
		}else{$(this).prepend("<span class='ui-icon ui-icon-bullet' style='float:left;cursor:pointer;'></span>");}
	});
	//$('li.tree').click(function(){if($(this).attr('link')){location.href = conf.contextPath+$(this).attr('link');}});
	$('li.tree[link]').each(function(){
		if(aftrCntxtPth.startsWith(conf.contextPath+$(this).attr('link'))){$(this).addClass('tree-selected');}
		//if(aftrCntxtPth.includes($(this).attr('link'))){$(this).addClass('tree-selected');}
	});
	$('.only-numeric').onlyNumeric();
	$('.only-decimal').onlyDecimal();
	if($('.page-body').find('.recs-widget').length > 0){
		conf.pageBody = $('.page-body').recsWidget();
	}
	
	$('#ssnOutPopup').dialog({autoOpen:false,height: 130,width: 300,resizable:false,modal: true,
		buttons: {
			'Extend':function(){
					$.ajax({url: conf.contextPath+"/test/dummySsnExtnd",type : "post",dataType :'json',	contentType :'application/json',cacheable : false,data:'{}',success: function(data){$('#ssnOutPopup').dialog('close');}});
			},'Logout': function(e){$('#logout').submit();}
		}
	});
});//End document ready.


function addError(err){ $('.succErrItemLst').maxZEl().append('<div class="errorItem"><span class="ui-icon ui-icon-circle-close ui-icon-red" style="float:left"></span>'+err+'</div>');}
function addSuccess(succ){$('.succErrItemLst').maxZEl().append('<div class="succItem"><span class="ui-icon ui-icon-circle-check  ui-icon-green" style="float:left"></span>'+succ+'</div>');}
function putErrorMsgs(msgs){$('.succErrItemLst').html('');for ( var g = 0; g < msgs.length; g++) {addError(msgs[g]);}$(document).one('click',function(e){$('.succErrItemLst').html('');if($('.ui-tabs').length > 0){$('.ui-tabs').tabs('refresh');}});if($('.ui-tabs').length > 0){$('.ui-tabs').tabs('refresh');}$('.page-body').scrollTop(0);$('.succErrItemLst').scrollParent().scrollTop(0);$('.succErrItemLst').parent().scrollTop(0);}
function putSuccMsgs(msgs){$('.succErrItemLst').html('');for ( var g = 0; g < msgs.length; g++) {addSuccess(msgs[g]);}$(document).one('click',function(e){$('.succErrItemLst').html('');if($('.ui-tabs').length > 0){$('.ui-tabs').tabs('refresh');}});if($('.ui-tabs').length > 0){$('.ui-tabs').tabs('refresh');}$('.page-body').scrollTop(0);$('.succErrItemLst').scrollParent().scrollTop(0);$('.succErrItemLst').parent().scrollTop(0);}
function putErrorMsgsE(msgs,e){$('.succErrItemLst').html('');e.preventDefault();e.stopPropagation();for ( var g = 0; g < msgs.length; g++) {addError(msgs[g]);}$(document).one('click',function(e){$('.succErrItemLst').html('');});$('.page-body').scrollTop(0);$('.succErrItemLst').scrollParent().scrollTop(0);$('.succErrItemLst').parent().scrollTop(0);}
function putSuccMsgsE(msgs,e){$('.succErrItemLst').html('');e.preventDefault();e.stopPropagation();for ( var g = 0; g < msgs.length; g++) {addSuccess(msgs[g]);}$(document).one('click',function(e){$('.succErrItemLst').html('');});$('.page-body').scrollTop(0);$('.succErrItemLst').scrollParent().scrollTop(0);$('.succErrItemLst').parent().scrollTop(0);}

var disabledZoneUseCount = 0;
var preHookTimeout = 1200000;
function ajaxPreHook(requestedUrl){
	if(!isExcludedUlr(requestedUrl)){
	 if ($('#disabledZone').length == 0) {
		  $('<div id="disabledZone"/>').css({'position' : 'absolute','z-Index' : '3000', 'left' : '0px' , 'top' : '0px', 'right' : '0px', 'bottom' : '0px'}).appendTo($('body'));
		  if (window.ActiveXObject) {$('#disabledZone').css({'background' : 'white', 'filter' : 'alpha(opacity=0)'});} 
		  $('<div id="messageZone" style="z-index:5000; position: absolute;top: 50%;left: 50%;margin-top: -25px; margin-left: -25px;width: 50px; height: 50px;"><img src="'+conf.contextPath+'/static/images/processing.gif"/><div style="white-space: nowrap;font-size: x-small;">Processing...</div></div>').appendTo($('body'));
		  var tOut = setTimeout("disabledZoneUseCount = 0;$('#disabledZone').remove();$('#messageZone').remove();",preHookTimeout);
		  $('#disabledZone').data('tOut',tOut);
		}
	 disabledZoneUseCount++; 
	}
}
function ajaxPostHook(requestedUrl){
	if(!isExcludedUlr(requestedUrl)){
		disabledZoneUseCount--;
	    if (disabledZoneUseCount < 0 || disabledZoneUseCount == 0) {
	    	disabledZoneUseCount = 0;clearTimeout($('#disabledZone').data('tOut'));
	    	$('#disabledZone').remove();$('#messageZone').remove();
	    } 
	    conf.inactiveIntervalRemaining=conf.maxInactiveInterval;
		jsMillies = new Date().getTime();
	}
}

var urlForCheckMap={};
urlForCheckMap[conf.contextPath+'/feedexecution/rest/feedExecutions']=2; //2 bcoz one for preAjax and one for post
urlForCheckMap[conf.contextPath+'/reconciliationexecution/rest/reconExecutions']=2;
urlForCheckMap[conf.contextPath+'/reportexecution/rest/reportExecutions']=2;

urlForCheckMap[conf.contextPath+'/home/rest/reconExecutions']=2;
urlForCheckMap[conf.contextPath+'/home/rest/reportExecutions']=2;
urlForCheckMap[conf.contextPath+'/home/rest/feedExecutions']=2;
urlForCheckMap[conf.contextPath+'/test/seqScheduleList']=2;
urlForCheckMap[conf.contextPath+'/home/rest/seqJobExecutions']=2;

urlForCheckMap[conf.contextPath+'/executionsummary/rest/reconExecutions']=2;
urlForCheckMap[conf.contextPath+'/executionsummary/rest/reportExecutions']=2;
urlForCheckMap[conf.contextPath+'/executionsummary/rest/feedExecutions']=2;
urlForCheckMap[conf.contextPath+'/executionsummary/rest/seqScheduleList']=2;
urlForCheckMap[conf.contextPath+'/executionsummary/rest/seqJobExecutions']=2;
urlForCheckMap[conf.contextPath+'/dragndrop/rest/jobFlow']=2;
urlForCheckMap[conf.contextPath+'/dragndrop/rest/jobDtls']=2;
urlForCheckMap[conf.contextPath+'/dragndrop/rest/runningStatus']=2;

function isExcludedUlr(urlForCheck){
	
	//alert(feedExecutions)
	//alert(JSON.stringify(urlForCheckMap));
	
	var num = urlForCheckMap[urlForCheck];
	//alert(num);
	
	//alert( parseInt(num) == 0);
	
	if(num!=undefined && parseInt(num) > 0){
		urlForCheckMap[urlForCheck] = (num-1);
		//alert(false);
		return false;
	}else if(num!=undefined && parseInt(num) == 0){
		//alert('true');
		return true;
	}
	//alert(num);
	return false;
}

function getCookie(cookieName){
	  var re = new RegExp(cookieName + "=([^;]+)");
	  var value = re.exec(document.cookie);
	  return (value != null) ? unescape(value[1]) : null;
}
function expireCookie(cookieName){document.cookie=encodeURIComponent(cookieName)+"=deleted; expires="+new Date( 0 ).toUTCString();}
function downloadStart(){setTimeout(ajaxPreHook, 10);}
var recsDownloadTimer;
function popToDownload(downloadUrl,params){
	
	
	var recsDownloadToken = new Date().getTime();
	var input = "<input type='hidden' name='recsDownloadToken' value='"+recsDownloadToken+"'><input type='hidden' id='_csrf' name='_csrf' value='"+$('input[name="_csrf"]').val()+"'><input type='hidden' id='viewState' name='viewState' value='"+$('#viewState').val()+"'><input type='hidden' id='noStateChange' name='noStateChange' value='noStateChange'>";
	if(params){for (var name in params) {input = input + "<input type='hidden' id='"+name+"' name='"+name+"' value='"+params[name]+"'>";}}
	$('#recsDownloader').remove();
	recsDownloadTimer = window.setInterval( function() {if(recsDownloadToken==getCookie("recsDownloadToken")){window.clearInterval(recsDownloadTimer);expireCookie("recsDownloadToken");ajaxPostHook('');}},100);
	var form = $('<form/>',{action:downloadUrl,method:'POST',html:input}).appendTo($('<iframe id="recsDownloader"/>').hide().appendTo('body'));
	form.bind('submit',downloadStart);
	form.submit();

}

function uploadFilesWithParams1(url,inputIds,params,callback){
	var frameId = 'frameIdIF',divID = 'upldFrmDv',frmDv='frmDv'; $('#'+divID).remove(); $('#'+frmDv).remove();
	$("<div id='uploadFrameDiv'></div>")
	.html("<iframe frameborder='0' style='width:0px;height:0px;border:none;position:absolute;left:-999;'  src='javascript:void(0)' id='" + frameId + "' name='" + frameId + "'></iframe>")
   .appendTo('body');
   $('#'+frameId).load(function () {
	   var iBody = $('#'+frameId).contents().find('body');var data = ""; if(iBody.find('pre').length > 0){data = $('#'+frameId).contents().find('body').find('pre').html();}
	   else{data = $('#'+frameId).contents().find('body').html();} $('#'+divID).remove(); $('#'+frmDv).remove();
	   if(callback!=null && callback!='undefined'){
		   //alert(data);
		   callback($.parseJSON(data));
		} ajaxPostHook(''); data="";
   });
   $('<div id="frmDv"></div>').html("<form enctype='multipart/form-data' encoding='multipart/form-data'></form>").appendTo('body');
   var form = $('#frmDv').children(':first-child');
   form.attr("action", url).attr("target", frameId).attr("style", "display:none").attr("method", 'post');
   if(inputIds){for (var id in inputIds) {
	   var inputId = inputIds[id]; var value = $('#'+inputId); var clone = value.clone(true);
	   clone.insertBefore(value); value.removeAttr("id").attr("name", inputId).css('display',"none");
	   form.append(value.detach())
   }}
   //alert(form.find('input').val());
  var input = $('#logout').html();if(params){for (var name in params) {input = input + "<input type='hidden' id='"+name+"' name='"+name+"' value='"+params[name]+"'>";}}
  form.append(input);
  ajaxPreHook('');form.submit();
}

function uploadFilesWithParams(url,inputIds,params,callback){
	var data = new FormData();
	$.each($('#'+inputIds[0])[0].files, function(i, file) {
	    data.append('file-'+i, file);
	});
	if(params){for (var name in params) {data.append(name, params[name]);}}
	$.ajax({
	    url: url,data: data,cache: false,contentType: false,processData: false, method: 'POST',
		type: 'POST', // For jQuery < 1.9
	    success: function(data){callback(data);},
		error:function(){alert('Error . . .');}
	});
}

// Pdf Report creation and Download functionality: Start 
function uploadImagesWithParams(url,inputIds , reportImgIds , boolValues , params ,callback){
	var len = boolValues.length ; 
	var data = new FormData() ;  
	for(var i = 0 ; i < len ; i++){
    var flag = boolValues[i] ; 
    if(flag){	
    var fileInput = document.getElementById(inputIds[i]) ; 
	var files = fileInput.files ; 
	if(files.length==0){
		data.append(inputIds[i] , reportImgIds[i] ) ; 
	}else{	
	var logoFile = files[0] ; 
	data.append(inputIds[i] , logoFile) ;
	}
	}else{
		data.append(inputIds[i] , reportImgIds[i] ) ; 
	}
	
	}

	$.ajax({
	    url: url,data: data,cache: false,contentType: false,processData: false, method: 'POST',
		type: 'POST', // For jQuery < 1.9
	    success: function(data){callback(data);},
		error:function(){alert('Error . . .');}
	});
}


// Pdf Report creation and Download functionality: End




//Start: Bulk Operation
function uploadFilesWithParamsForMultipleInputs(url,inputIds,params,callback){
	var data = new FormData();
	$.each(inputIds, function(index, inputId){
		$.each($('#'+inputId)[0].files, function(i, file) {
	    data.append(inputId+'-'+i, file);
	});
	});
	/*$.each($('#'+inputIds[0])[0].files, function(i, file) {
	    data.append('file-'+i, file);
	});*/
	if(params){for (var name in params) {data.append(name, params[name]);}}
	$.ajax({
	    url: url,data: data,cache: false,contentType: false,processData: false, method: 'POST',
		type: 'POST', // For jQuery < 1.9
	    success: function(data){callback(data);},
		error:function(){alert('Error . . .');}
	});
}
//End: Bulk Operation

/* conf.contextPath
$('#testExpr').expressionbuilder(
	{
	datatype:'boolean',
	operators:['-','+','*','/','==','!'],
	operatordatatypes:['number','number','number','number','boolean','boolean'],
	operatorargumentdatatypes:[
		['number','number'],
		['number','number'],
		['number','number'],
		['number','number'],
		['number','number'],
		['boolean']
	],
	functions:['concatstr','strlen','addint','currtime','add3nums','add4nums'],
	functiondatatypes:['string','number','number','datetime','number','number'],
	functionargumentdatatypes:[
		['string','string'],
		['string'],
		['number','number'],
		[],
		['number','number','number'],
		['number','number','number','number']
	],
	columns:['ID','F_NAME','L_NAME','DEPT','LOCATION','SALARY','DOB'],
	columndatatypes:['number','string','string','string','string','number','datetime'],
	columnargumentdatatypes:[]
	}
);
	*/
	
	////AES Encryption
	function encryptData(data){
		var secretKeyBase64 = conf.secretKey;
		var key = CryptoJS.enc.Base64.parse(secretKeyBase64);
		var encQry = CryptoJS.AES.encrypt(data,key,{
			mode: CryptoJS.mode.ECB,
			padding: CryptoJS.pad.Pkcs7,
		});
		return encQry.toString();
	}
	
	(function(){
		const origOpen = XMLHttpRequest.prototype.open;
		const origSend = XMLHttpRequest.prototype.send;
		XMLHttpRequest.prototype.open = function(method,url){
			this._url=url;
			return origOpen.apply(this,arguments);
		}
		XMLHttpRequest.prototype.send = function(body){
			var flag = conf.encryptionFlag;
			var url = this._url;
			if(flag == 'Y'){
				if(url && url.includes(conf.contextPath + '/sqlwizard/sqlwizardData')){
					var reqBody = JSON.parse(body);
					var qry = reqBody.otherParams.SQLQUERY;
					reqBody.otherParams.SQLQUERY = encryptData(qry);
					body = JSON.stringify(reqBody);
				}
				if(url && url.includes(conf.contextPath + '/feedconfiguration/rest/validateFeedExceptColDtls')){
					var reqBody = JSON.parse(body);
					var qry = reqBody.tableQuery;
					reqBody.tableQuery = encryptData(qry);
					body = JSON.stringify(reqBody);
				}
				if(url && url.includes(conf.contextPath + '/feedconfiguration/rest/dbfeedcolumns')){
					var reqBody = JSON.parse(body);
					var qry = reqBody.tableQuery;
					reqBody.tableQuery = encryptData(qry);
					body = JSON.stringify(reqBody);
				}
				if(url && url.includes(conf.contextPath + '/feedconfiguration/rest/savefeed')){
					var reqBody = JSON.parse(body);
					var qry = reqBody.tableQuery;
					reqBody.tableQuery = encryptData(qry);
					body = JSON.stringify(reqBody);
				}
				if(url && url.includes(conf.contextPath + '/reportconfiguration/comb/rest/saveSqlXlsxTempltReport')){
					var reqBody = JSON.parse(body);
					var sqlConfigs = reqBody.sqlConfigs;
					for(let i=0; i<sqlConfigs.length; i++){
						reqBody.sqlConfigs[i].sql = encryptData(sqlConfigs[i].sql);
					}
					body = JSON.stringify(reqBody);
				}
				if(url && url.includes(conf.contextPath + '/reportconfiguration/comb/rest/validateSqlTemplatedReportDetails')){
					var reqBody = JSON.parse(body);
					var sqlConfigs = reqBody.sqlConfigs;
					for(let i=0; i<sqlConfigs.length; i++){
						reqBody.sqlConfigs[i].sql = encryptData(sqlConfigs[i].sql);
					}
					body = JSON.stringify(reqBody);
				}
			}
			return origSend.call(this,body);
		}
	})();
	///////////////////
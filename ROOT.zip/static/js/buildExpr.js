$.fn.oprnexpressionbuilder=function(expressionbuilderdata){//datatype can be number,string,boolean or datetime
	/*if(!(expressionbuilderdata.functions && expressionbuilderdata.functions.length >0)){
		expressionbuilderdata.functions=[];
		expressionbuilderdata.functiondatatypes=[];
		expressionbuilderdata.functionargumentdatatypes=[];
	}
	expressionbuilderdata.functions.push('numberValue');
	expressionbuilderdata.functions.push('stringValue');
	expressionbuilderdata.functions.push('datetimeValue');
	expressionbuilderdata.functions.push('booleanValue');
	
	expressionbuilderdata.functiondatatypes.push('number');
	expressionbuilderdata.functiondatatypes.push('string');
	expressionbuilderdata.functiondatatypes.push('datetime');
	expressionbuilderdata.functiondatatypes.push('boolean');
	
	expressionbuilderdata.functionargumentdatatypes.push(['number']);
	expressionbuilderdata.functionargumentdatatypes.push(['string']);
	expressionbuilderdata.functionargumentdatatypes.push(['datetime']);
	expressionbuilderdata.functionargumentdatatypes.push(['boolean']);
	*/
	return this.each(function(){//expressionbuilderdata = {datatype:'string',operators:['-','+','*','/'],functions:['concatstr','strlen','addint','currtime'],columns:['ID','F_NAME','L_NAME','DEPT','LOCATION']}
		var el = $(this).data('expressionbuilderdata',expressionbuilderdata).data('cols',[]);
		$('<table style="float:left;"><tr><td class="expressionelement operator" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Operator</td><td class="expressionelement function" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Function</td><td class="expressionelement records" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Records</td><td class="expressionelement record" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Record</td><td class="expressionelement colName" style="cursor:pointer !important; border: 1px solid #c3d9ff;opacity:0.35;">Col Name</td><td class="expressionelement literal" style="cursor:pointer !important; border: 1px solid #c3d9ff;display:none;opacity:0.35;">Literal</td></tr></table>')
		//<td class="ui-state-disabled expressionelement column" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Column</td><td class="ui-state-disabled expressionelement record" style="cursor:pointer !important; border: 1px solid #c3d9ff;">Record</td>
		.appendTo($(this)/*.disableSelection()*/.css({height:'25px',fontSize:'14px'})).attr('datatype',expressionbuilderdata.datatype);
		var popid = $(this).attr('id')+'_'+Math.floor((Math.random()*10000)+1)+'_'+(new Date().getMilliseconds());
		$('<div style="width:200px; height:100px; z-index: 10; position: absolute;display:none;" class="expressionpop"><table class="ui-widget-content" style="border-collapse: collapse; width:100%; height:100%; position: absolute; top:0px; left:0px;"><tr style="height: 20px;" class="ui-widget-header"><th id="expressionhandle" style="border: 1px solid #c3d9ff;cursor: move;font-size:1rem;"></th></tr><tr><td align="center" id="expressioncontent"></td></tr><tr><td align="center"><button id="ok">Ok</button>&nbsp;&nbsp;&nbsp;&nbsp;<button id="cancel">Cancel</button></td></tr></table></div>')
		.appendTo($(this)).attr('id',popid).find('button').button().click(function(){
			
			if($(this).attr('id')=='ok'){
				var expval = '';
				var color='#'+(Math.random().toString(16) + '0000000').slice(2, 8);
				if($(this).closest('tr').prev().find('select').length!=0){expval = $(this).closest('tr').prev().find('select').val();}
				else{expval = $(this).closest('tr').prev().find('input').val();}
				if(expval!='' && expval!='select'){
					if($('#'+popid).data('expressionelement').is('.operator')){
						var tbl = $('#'+popid).data('expressionelement').closest('table');
						var expdata = tbl.parent().data('expressionbuilderdata');
						var argdatatypes = expdata.operatorargumentdatatypes[$.inArray(expval,expdata.operators)];
						var tempTbl;
						if(argdatatypes.length==2){
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
							tempTbl = tbl.clone().attr('datatype',argdatatypes[1]);
							tempTbl.find('.literal').hide();
							tempTbl.find('.expressionelement').each(function(){
								var dtTyp = tempTbl.attr('datatype');
								var thisVis=false;
								if($(this).is('.operator')){
									for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.function')){
									for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.column')){
									for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.record')){
									if(dtTyp=='record'){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.records')){
									if(dtTyp=='records'){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.colName')){
									if(dtTyp=='colName'){$(this).show();}else{$(this).hide();}
								}
							});
							tbl.after(tempTbl);
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">&nbsp; '+expval+' &nbsp;</div>');
							tempTbl = tbl.clone().attr('datatype',argdatatypes[0]);
							tempTbl.find('.expressionelement').each(function(){
								var dtTyp = tempTbl.attr('datatype');
								var thisVis=false;
								if($(this).is('.operator')){
									for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.function')){
									for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.column')){
									for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
									if(thisVis==true){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.record')){
									if(dtTyp=='record'){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.records')){
									if(dtTyp=='records'){$(this).show();}else{$(this).hide();}
								}else if($(this).is('.colName')){
									if(dtTyp=='colName'){$(this).show();}else{$(this).hide();}
								}
							});
							tbl.after(tempTbl);
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">(</div>');
						}else if(argdatatypes.length==1){
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
							tbl.after(tbl.clone().attr('datatype',argdatatypes[0]));
							tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'</div>');
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">(</div>');
						}
					}else if($('#'+popid).data('expressionelement').is('.function')){
						var tbl = $('#'+popid).data('expressionelement').closest('table');
						var expdata = tbl.parent().data('expressionbuilderdata');
						//alert(JSON.stringify(expval));
						var argdatatypes = expdata.functionargumentdatatypes[$.inArray(expval,expdata.functions)];
						var tempTbl;
						if(argdatatypes.length > 0){
							for ( var i = (argdatatypes.length - 1); i >= 0 ; i--) {
								tempTbl = tbl.clone().attr('datatype',argdatatypes[i]);
								//alert(argdatatypes[i]);
								tempTbl.find('.expressionelement').each(function(){
									var dtTyp = tempTbl.attr('datatype');
									var thisVis=false;
									
									if($(this).is('.operator')){
										for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if('any'==dtTyp || dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
										//alert("operator "+dtTyp+"  "+thisVis);
									}else if($(this).is('.function')){
										for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if('any'==dtTyp || dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
										//alert("function "+dtTyp+"  "+thisVis);
									}else if($(this).is('.column')){
										for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if('any'==dtTyp || dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
										if(thisVis==true){$(this).show();}else{$(this).hide();}
									}else if($(this).is('.record')){
										if(dtTyp=='record'){$(this).show();}else{$(this).hide();}
									}else if($(this).is('.records')){
										if(dtTyp=='records'){$(this).show();}else{$(this).hide();}
									}else if($(this).is('.colName')){
										if(dtTyp=='colName'){$(this).show();}else{$(this).hide();}
									}
								});
								if($.inArray(expval,['numberValue','stringValue','datetimeValue','booleanValue']) > -1){
									tempTbl.find('.literal').show();tempTbl.find('.operator,.function,.column,.record,.records').hide();
								}
								if(i==(argdatatypes.length - 1)){
									if(argdatatypes.length==1){
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
										tbl.after(tempTbl);
										tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'(</div>');
									}else{
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">)</div>');
										tbl.after(tempTbl);
										tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">,</div>');
									}
								}else if(i==0){
									tbl.after(tempTbl);
									tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'(</div>');
								}else{
									tbl.after(tempTbl);
									tbl.after('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">,</div>');
								}
							}	
						}else{
							tbl.replaceWith('<div style="float:left;vertical-align: middle;font-weight: bold;color:'+color+';">'+expval+'()</div>');
						}
					}else if($('#'+popid).data('expressionelement').is('.column')){
						$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">'+expval+'</div>');
						var cols = el.data('cols');
						if($.inArray(expval,cols)==-1){
							cols.push(expval);
						}
						el.data('cols',cols);
					}else if($('#'+popid).data('expressionelement').is('.literal')){
						if($('#'+popid).data('expressionelement').closest('table').attr('datatype') == 'string'){
							$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">\''+expval+'\'</div>');
						}else if($('#'+popid).data('expressionelement').closest('table').attr('datatype') == 'datetime'){
							$('#'+popid).data('expressionelement').closest('table').replaceWith("<div style=\"float:left;color:"+color+";\">toDate('"+expval+"','dd-MM-yyyy hh:mm aa')</div>");
						}else{
							$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">\''+expval+'\'</div>');
						}
					}else if($('#'+popid).data('expressionelement').is('.record')){
						$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">'+expval+'</div>');
					}else if($('#'+popid).data('expressionelement').is('.records')){
						$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">'+expval+'</div>');
					}else if($('#'+popid).data('expressionelement').is('.colName')){
						$('#'+popid).data('expressionelement').closest('table').replaceWith('<div style="float:left;color:'+color+';">\''+expval+'\'</div>');
					}
						
					$('#'+popid).hide();
				}
			}else if($(this).attr('id')=='cancel'){$('#'+popid).hide();}
		});
		var _hideexpressionspopup = function(ev){
			if (!($('#'+popid).is(ev.target)) && $('#'+popid).has(ev.target).length === 0 && $(ev.target).closest('.ui-datepicker').length == 0
		&& $(ev.target).closest('.ui-datepicker-header').length == 0 && $(ev.target).closest('.ui-selectmenu-menu').length == 0
		){$('#'+popid).hide();}};
		$(this).find('.expressionelement').each(function(){
			var dtTyp = $(this).closest('table').attr('datatype');
			var thisVis=false;
			if($(this).is('.operator')){
				for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if(dtTyp==expressionbuilderdata.operatordatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.function')){
				for (var i = 0; i < expressionbuilderdata.functions.length; i++) {if(dtTyp==expressionbuilderdata.functiondatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.column')){
				for (var i = 0; i < expressionbuilderdata.columns.length; i++) {if(dtTyp==expressionbuilderdata.columndatatypes[i]){thisVis=true;break;}}
				if(thisVis==true){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.record')){
				if(dtTyp=='record'){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.records')){
				if(dtTyp=='records'){$(this).show();}else{$(this).hide();}
			}else if($(this).is('.colName')){
				if(dtTyp=='colName'){$(this).show();}else{$(this).hide();}
			}
		});
		$(this).on('click','.expressionelement',function(e){
			$('#'+popid).show().draggable({handle:$('#expressionhandle'),containment:'document'}).data('expressionelement',$(this)).position({of:$(this),at:"left bottom",my:"left top"}).find('#expressionhandle').html($(this).html());
			$(document).unbind('click',_hideexpressionspopup).click(_hideexpressionspopup);
			e.preventDefault();e.stopPropagation();$(document).find('.expressionpop:not("#'+popid+'")').hide();
			var expcont = $('#'+popid).find('#expressioncontent').html('');
			var inputStr = '';
			var dt = $(this).closest('table').attr('datatype');
			if($(this).is('.operator')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.operators.length; i++) {if('any'==dt || 'any'==expressionbuilderdata.operatordatatypes[i] || dt==expressionbuilderdata.operatordatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.operators[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.function')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.functions.length; i++){if('any'==dt || 'any'==expressionbuilderdata.functiondatatypes[i] || dt==expressionbuilderdata.functiondatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.functions[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.column')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.columns.length; i++){if('any'==dt || 'any'==expressionbuilderdata.columndatatypes[i] || dt==expressionbuilderdata.columndatatypes[i]){inputStr = inputStr+'<option>'+expressionbuilderdata.columns[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.records')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				if(dt=='records'){for (var i = 0; i < expressionbuilderdata.records.length; i++){inputStr = inputStr+'<option>'+expressionbuilderdata.records[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.record')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				if( dt=='record'){for (var i = 0; i < expressionbuilderdata.record.length; i++){inputStr = inputStr+'<option>'+expressionbuilderdata.record[i]+'</option>';}}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.colName')){
				inputStr = '<select style="width:80%;"><option value="select">--Select--</option>';
				for (var i = 0; i < expressionbuilderdata.columns.length; i++){inputStr = inputStr+'<option>'+expressionbuilderdata.columns[i]+'</option>';}
				inputStr = inputStr+'</select>';expcont.append(inputStr);
			}else if($(this).is('.literal')){
				if('boolean'!=$(this).closest('table').attr('datatype')){
					inputStr = '<input style="width:70%;">';
					expcont.append(inputStr);
					if(dt=='number'){
						expcont.find('input').keydown(function(e){
							if(e.keyCode==190 && $(this).val().indexOf(".")!=-1){e.preventDefault();}
							if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || (e.keyCode >= 35 && e.keyCode <= 40)) {return;}
						    if((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || (e.keyCode > 105))){e.preventDefault();}
						});
					}else if(dt=='datetime'){
						expcont.find('input').datetimepicker({timeFormat:"hh:mm tt"});
					}	
				}else{
					inputStr = '<select style="width:80%;"><option value="select">--Select--</option><option value="True">True</option><option value="False">False</option></select>';
					expcont.append(inputStr)
				}
			}
		});
	});
};
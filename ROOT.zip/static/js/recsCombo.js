/*
 * $('#testCombo').recsCombo();//.recsCombo('title',"Asdf");
 * 
 * $('#testCombo').recsCombo('addOption','added','Added Desc');
 * $('#testCombo').recsCombo('addOption','added no desc');
 * 
 * $('#testCombo').recsCombo('val')
 * 
 */
$(function(){

	/*
	 * Start - combobox copied from jQuery Ui page
	 */
	$.widget( "recs.recsCombo", {
	    _create: function() {
	      this.wrapper = $( "<span>" )
	        .addClass( "custom-combobox" )
	        .insertAfter( this.element );

	      this.element.hide();
	      this.element.addClass('recs-combo');
	      this._createAutocomplete();
	      this._createShowAllButton();
	      
	      var v = this.element.attr('val');
	      if(v!=undefined && v!=''){
		      var validVal = false;
		      var valueLC = v.toLowerCase();
      	      this.element.children( "option" ).each(function() {
      	        if ( $( this ).text().toLowerCase() === valueLC ) {
      	          this.selected = validVal = true;
      	          return false;
      	        }
      	      });
      	    this.input.val( v ); 
      	      if(!validVal){
      	    	this.element.val( "" );
      	      }
	      }
	    },

	    _createAutocomplete: function() {
	      var selected = this.element.children( ":selected" ),
	        value = selected.val() ? selected.text() : "";

	      this.input = $( "<input>" )
	        .appendTo( this.wrapper )
	        .val( value )
	        //.attr( "title", "" )
	        .addClass( "custom-combobox-input ui-widget ui-widget-content ui-corner-left" )
	        .autocomplete({
	          delay: 0,
	          minLength: 0,
	          source: $.proxy( this, "_source" )
	        })
	        /*.tooltip({
	          classes: {
	            "ui-tooltip": "ui-state-highlight"
	          }
	        })*/;
	     

	      this.input.autocomplete( "instance" )._renderItem = function( ul, item ) {
	  	  //alert(JSON.stringify(item));
	    	  var desc = "";
	    	  if(item.desc && item.desc!="" && item.desc!=undefined){desc = "<br><span style='color:#C2C2DD;font-family: calibri,times;font-size: 12px;'>"+ item.desc + "</span>";}
	          return $( "<li>" )
	          .append( "<div>" + item.label + desc + "</div>" )
	          .appendTo( ul );
	  	  //alert(ul.html());
	  	  //return ul;
	      };

	      this._on( this.input, {
	        autocompleteselect: function( event, ui ) {
	          ui.item.option.selected = true;
	          this._trigger( "select", event, {
	            item: ui.item.option
	          });
	        },

	       autocompletechange: "_removeIfInvalid"
	      });
	    },

	    _createShowAllButton: function() {
	      var input = this.input,
	        wasOpen = false;

	      $( "<a>" )
	        .attr( "tabIndex", -1 )
	        //.attr( "title", "Show All Items" )
	        //.tooltip()
	        .appendTo( this.wrapper )
	        .button({
	          icons: {
	            primary: "ui-icon-triangle-1-s"
	          },
	          text: false
	        }).width(16)
	        .removeClass( "ui-corner-all" )
	        .addClass( "custom-combobox-toggle ui-corner-right" )
	        .on( "mousedown", function() {
	          wasOpen = input.autocomplete( "widget" ).is( ":visible" );
	        })
	        .on( "click", function() {
	          input.trigger( "focus" );

	          // Close if already visible
	          if ( wasOpen ) {
	            return;
	          }

	          // Pass empty string as value to search for, displaying all results
	          input.autocomplete( "search", "" );
	        });
	    },

	    _source: function( request, response ) {
	      var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
	      response( this.element.children( "option" ).map(function() {
	        var text = $( this ).text();
	        var dec = $( this ).attr('desc');
	        if ( this.value && ( !request.term || matcher.test(text) ) )
	          return {
	            label: text,
	            value: text,
	            desc:dec,
	            option: this
	          };
	      }) );
	    },

	    _removeIfInvalid: function( event, ui ) {

	      // Selected an item, nothing to do
	      if ( ui.item ) {
	        return;
	      }

	      // Search for a match (case-insensitive)
	      var value = this.input.val(),
	        valueLowerCase = value.toLowerCase(),
	        valid = false;
	      this.element.children( "option" ).each(function() {
	        if ( $( this ).text().toLowerCase() === valueLowerCase ) {
	          this.selected = valid = true;
	          return false;
	        }
	      });

	      // Found a match, nothing to do
	      if ( valid ) {
	        return;
	      }

	      // Remove invalid value
	      //this.input.val( "" ).attr( "title", value + " didn't match any item" ).tooltip( "open" );
	      this.element.val( "" );
	      //this._delay(function() {
	      //  this.input.tooltip( "close" ).attr( "title", "" );
	      //}, 2500 );
	      //this.input.autocomplete( "instance" ).term = "";
	    },
	    _destroy: function() {
	      this.wrapper.remove();
	      this.element.show();
	      this.element.removeAttr('display');
	    },
	    val:function(value){
	    	if ( value === undefined ) {
	    		return this.element.val()==""?this.input.val():this.element.val();
	    	}else{
	    		var inp = this.input;
	    		inp.val("");
	    		var value = this.input.val(),valueLowerCase = value.toLowerCase();
	            this.element.children("option").each(function() {
	            if($(this).text().toLowerCase() === valueLowerCase){
	              this.selected = true;
	              inp.val($(this).text());
	              return false;
	            }
	          });
	            if(inp.val()==""){
	            	this.element.find("option:first").prop('selected',true);
	            	inp.val(value);
	            }
	    	}
	    },
	    title:function(ttl){
	    	this.wrapper.find('a').tooltip({content:ttl} );
	    },
	    addOption:function(val,desc){
	    	var option = '<option value="'+val+'"';
	    	if(desc!=undefined){
	    		option = option+' desc="'+desc+'" ';
	    	}
	    	option = option+'>'+val+'</option>';
	    	this.element.append(option);
	    }
	  });

	/*
	 * End - combobox copied from jQuery Ui page
	 */
	
});